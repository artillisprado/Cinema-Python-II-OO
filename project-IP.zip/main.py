from interface import interfaceConsole
interface = interfaceConsole()
interface.inicio()

